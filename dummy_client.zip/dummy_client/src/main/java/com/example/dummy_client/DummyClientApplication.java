package com.example.dummy_client;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DummyClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(DummyClientApplication.class, args);
	}

}
